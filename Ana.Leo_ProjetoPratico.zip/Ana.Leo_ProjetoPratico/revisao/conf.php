<?php
    include "conexao.php";

    $alt = "Descrição da imagem";
    $desenvolvedor = "Ana Julia & José Leonardo";
    $menu = array(
                    "modelo"=>"Modelo do instrumento",            
                    "cor"=>"Cor do instrumento",
                    "instrumento"=>"Instrumentos",
                );

    include "cabecalho.php";
    include "rodape.php";

?>
