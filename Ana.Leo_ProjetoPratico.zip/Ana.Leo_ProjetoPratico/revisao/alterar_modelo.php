<form>
    <div class="form-group">
		<div class="input-group">
            <input type="text" name="nome" id="nome" placeholder="Modelo...">
            <input type="hidden" name="id_modelo" id="id_modelo">
        </div>
    </div>
</form>