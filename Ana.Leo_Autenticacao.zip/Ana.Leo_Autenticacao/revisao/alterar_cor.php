<form>
    <div class="form-group">
        <div class="input-group">
            <input type="text" name="nome" id="nome" placeholder="Cor do instrumento...">
            <input type="hidden" name="id_cor" id="id_cor">
        </div>
    </div>
 </form>