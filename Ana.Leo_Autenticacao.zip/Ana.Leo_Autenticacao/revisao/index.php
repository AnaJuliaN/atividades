<?php
include "conf.php";

cabecalho();

echo "<div>Bem vindo ao site XYZ.</div>";

rodape();

?>